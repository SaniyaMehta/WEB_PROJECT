//sidenavbar.jsx
import React from "react";
import "./sidenavbar.css";
const SideNavbar = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-auto side-navbar">
          <ul>
            <li>
              <a className="nav-link" href="/home">
                <i className="bi-envelope" />
                <span className="ms-1 d-none d-sm-inline">Inbox</span>
              </a>
            </li>
            <li>
              <a className="nav-link" href="/dashboard">
                <i className="bi-bar-chart" />
                <span className="ms-1 d-none d-sm-inline">Dashboard</span>
              </a>
            </li>
            <li>
              <a className="nav-link" href="/calendar">
                <i className="bi-calendar-check" />
                <span className="ms-1 d-none d-sm-inline">Upcoming</span>
              </a>
            </li>
            <li>
              <a className="nav-link" href="/settings">
                <i className="bi-ui-checks-grid" />
                <span className="ms-1 d-none d-sm-inline">Filters</span>
              </a>
            </li>
            <li>
              <a className="nav-link" href="/">
                <i className="bi-box-arrow-right" />
                <span className="ms-1 d-none d-sm-inline">Logout</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SideNavbar;