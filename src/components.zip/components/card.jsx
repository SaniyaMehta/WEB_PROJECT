import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js"; //Bootstrap's JavaScript components
import { MdKeyboardDoubleArrowDown } from "react-icons/md";
import { SlCalender } from "react-icons/sl"; // Assuming SlCalender is a valid icon component
import { BsFillAlarmFill } from "react-icons/bs";
import { BiEditAlt } from "react-icons/bi";
import { BiCommentEdit } from "react-icons/bi";
import { CgCalendarDates } from "react-icons/cg";
import "./card.css";

const Card = () => {
  const [contentVisible, setContentVisible] = useState(true);
  const [inputValue, setInputValue] = useState("");
  const [listItems, setListItems] = useState([]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleAddItem = () => {
    if (inputValue) {
      setListItems([...listItems, inputValue]);
      setInputValue("");
    }
  };

  const toggleContent = () => {
    setContentVisible(!contentVisible);
  };

  return (
    <div className="card">
      <div className="title">
        Task Name
        <div className="arrowIconStyles" onClick={toggleContent}>
          <MdKeyboardDoubleArrowDown />
        </div>
      </div>
      {contentVisible && (
        <div className="content">
          <ul>
            {listItems.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
          <div className="custom-form">
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Add an item..."
              className={`custom-input ${contentVisible ? "enlarged" : ""}`}
            />
            <button onClick={handleAddItem} className="custom-button">
              Add
            </button>
          </div>
        </div>
      )}
      <div className="buttons">
        <button className="today-button" onClick={toggleContent}>
          <SlCalender /> Today
        </button>
        <div className="dropdown">
          <button
            className="btn dropdown-toggle priority-button"
            type="button"
            id="dropdownMenuButton"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          style={{}}>
            Priority
          </button>
          <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <li>
              <a className="dropdown-item" href="#!">
                High
              </a>
            </li>
            <li>
              <a className="dropdown-item" href="#!">
                Medium
              </a>
            </li>
            <li>
              <a className="dropdown-item" href="#!">
                Low
              </a>
            </li>
          </ul>
        </div>
        <button className="remainder-button" onClick={toggleContent}>
          <BsFillAlarmFill /> Reminder
        </button>
      </div>
      <div className="end">
        <button>Cancel</button>
        <button>Add Task</button>
      </div>
      <div className="bottom">
        <BiEditAlt title="Edit" />
        <BiCommentEdit title="Comment on tasks" />
        <CgCalendarDates title="Set Due date" />
      </div>
    </div>
  );
};

export default Card;
